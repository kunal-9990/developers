(function () {
    'use strict';

    if (!wpw.tax.gcs) wpw.tax.gcs = {};
    if (!wpw.tax.gcs.formLabels) wpw.tax.gcs.formLabels = {};
    let currentForm = 'cfEditModal'

    wpw.tax.gcs.formLabels[currentForm] = {
        formData: {
            "en": {
                setValueLabel: 'Set values below',
                formDataTitle: 'PA - Cash flow statement structures table',
                directOperatingHeader: 'Direct Operating activities',
                indirectOperatingHeader: 'Indirect Operating activities',
                investingHeader: 'Investing activities',
                financingHeader: 'Financing activities'
            },
        },
        tables: {
            "en": {
                directOperatingColumn: 'Direct Operating activities',
                indirectOperatingColumn: 'Indirect Operating activities',
                investingColumn: 'Investing activities',
                financingColumn: 'Financing activities',
                saveCFButton: 'Save',
                restoreCFButton: 'Restore Default',
                defaultCFButton: 'Set As New Default',
                clearAllButton: 'Clear All',
                cancelCFButton: 'Cancel',
            }
        },
        calc: {
            "en": {}
        }
    }

    wpw.tax.gcs.setProdGCSLabel(currentForm);

})();