(function () {
    'use strict';

    if (!wpw.tax.gcs) wpw.tax.gcs = {};
    if (!wpw.tax.gcs.formLabels) wpw.tax.gcs.formLabels = {};
    let currentForm = 'cfi'

    wpw.tax.gcs.hardLink = wpw.tax.gcs.hardLink || {};

    wpw.tax.gcs.hardLink["customizeRounding"] = "https://docs.caseware.com/2020/webapps/31/en/Engagements/Template-and-Authoring/Customize-rounding-in-the-financial-statements.htm?region=int"
    wpw.tax.gcs.hardLink["importToolValueKey"] = "https://developers.caseware.com/downloads/CashFlowImportTool/Nov_2023(Final)-Cash_Flow_Statement_Import_Tool-values_json_keys_(Global_Components).xlsx";
    wpw.tax.gcs.hardLink["copyPasteTool"] = "https://developers.caseware.com/se-authoring/31/Cash-flow-import-copy-paste-tool.htm";
    wpw.tax.gcs.hardLink["demoCsv"] = "https://developers.caseware.com/downloads/CashFlowImportTool/Nov_2023-CSV_Import_Templates_(no_Amounts-Direct&Indirect).rar";
    wpw.tax.gcs.hardLink["identifyProcedure"] =  "https://developers.caseware.com/se-authoring/31/How-to-identify-the-procedure-ID.htm";

    wpw.tax.gcs.formLabels[currentForm] = {
        formData: {
            "en": {
                prepared: `Prepared`,
                reviewed: `Reviewed`,
                overviewHeader: "Overview",
                formDataTitle: 'Cash flow import',
                operatingActivitiesHeader: "Operating activities",
                investingActivitiesHeader: "Investing activities",
                financingActivitiesHeader: "Financing activities",
                supplementalCashFlowHeader: "Supplemental cash flow",
                settingHeader: "Settings",
                guidanceTabHeader: "Guidance",
                guidanceHeader: "Guidance",
                overallGuidance:`The <b>Cash flow import / copy paste tool</b> saves the information using <b><em>Form values IDs</em></b>. To link the values between the SE Builder form and the Financial Statements, the primary author is required to author these <b><em>Form values IDs</em></b>  into the dynamic tables.
                <ul>
                    <li>To access a list of <b><em>Form values IDs</em></b> which are  linked to the financials dynamic tables, click <a href=${wpw.tax.gcs.hardLink.importToolValueKey} target=”_blank”>here.</a> Note that these are the default values shared and they can be modified by your solution SE developer (for example, translate the default descriptions you want to include). </li>
                    <li>For more details, see <a href=${wpw.tax.gcs.hardLink.copyPasteTool} target=”_blank”>Cash flow import / copy paste tool → Required Primary Author changes topic</a>.</li>
                </ul>
                <br>The <b>Cash flow import / copy paste tool</b> supports two methods to to insert the amounts into this form:
                <ul>
                    <li><b>CSV Import</b>: Import the amounts using the predefined CSV template file provided.</li>
                        <ul>
                            <li><b>Note</b>: CSV Import supports loading the information from a CSV file with a predefined format/structure. An example file can be found here: <a href=${wpw.tax.gcs.hardLink.demoCsv} target=”_blank”>CSV Import Template demo file</a>.</li>
                            <li>We recommend that each Solution team uses the example below and constructs their own specific import template based on your market requirements.</li>
                        </ul>
                    <li><b>Copy-Paste</b>: Allows you to directly copy and paste the amounts for each of the applicable cash flow sections.</li>
                </ul>`,
                frameworkLabel: 'Framework',
                industryLabel: 'Industry',
                cfMethodLabel: 'Cash Flow Method',
                settingTitle: 'Settings',
                frameworkIdLabel: 'Financial reporting framework procedure ID',
                frameworkIdGuidance:`If your app supports multiple financial reporting frameworks and different cash flow structures apply based on the financial reporting framework selected, insert the <b>procedure ID</b> where the end user selects the financial reporting framework applicable for the engagement.
                <br><br>If your app supports only one financial reporting framework, leave this field blank.
                <br><br>Refer to <a href=${wpw.tax.gcs.hardLink.identifyProcedure} target=”_blank”>this section</a> for instructions on how to identify the procedure.`,
                industryIdLabel: 'Industry procedure ID',
                industryIdGuidance:`If your app supports multiple industries and different cash flow structures apply based on the industry selected, insert the procedure ID where the end user selects the industry applicable for the engagement.
                <br><br>If your app supports only one industry, leave this field blank.
                <br><br>Refer to <a href=${wpw.tax.gcs.hardLink.identifyProcedure} target=”_blank”>this section</a> for instructions on how to identify the procedure.`,
                cfMethodIdLabel: 'Cash flow reporting method procedure ID',
                cfMethodIdGuidance:`Insert the procedure ID where the end user selects which method will be used for reporting the cash flows (Direct or Indirect methods).
                <br><br>Leave this field blank if only one reporting method is supported by your app.
                <br><br>By default, if no ID is provided, the Cash Flow import tool will insert the Indirect method.
                <br><br>Refer to <a href=${wpw.tax.gcs.hardLink.identifyProcedure} target=”_blank”>this section</a> for instructions on how to identify the procedure.`,
                checklistIdPlaceholder: 'Insert Procedure ID/leave blank',
                cfMethodSeqLabel: 'Select the response sequence for the Cash Flow method procedure.',
                cfMethodSeqGuidance: 'Specify which method corresponds to each of the Cash Flow method responses.',
                cfMethodSeqLabelY: 'Direct method',
                cfMethodSeqLabelN: 'Indirect method',
                cfDisableDesc: 'Do you want to restrict the ability to edit Cash Flow line descriptions at the engagement level?',
                cfDisableDescGuidance: 'Select <b>Yes</b> if you want to disable the ability for end-users to edit the lines\’ descriptions.',
                supplementCashFlowLabel: 'Do you want to include a Supplemental cash flow information section?',
                supplementCashFlowGuidance:'Select <b>Yes</b> if a Supplemental cash flow information section applies for your Solution. This will allow you to further customize it.',
                tbGroupNumber: 'Group Number',
                cfSetupStructureLabel: 'Cash flow structures setup',
                cfSetupStructureInfo:`Use the table below to set up the Cash Flow structures for each financial reporting framework and industry supported in your app based on the information provided in the above <b>Settings</b> section:
                <ul>
                    <li>Select each configuration applicable based on the Financial reporting framework and industry supported by your app.</li>
                    <li>Specify the number of rows that each <b>Cash Flow</b> section should include.
                        <ul>
                            <li><b>Note:</b> the maximum number of rows for each section is defined by the SE Builder author through the <b>values.json</b> file. A maximum of 40 rows for each section have been defined in the master version of this form. You can increase this number by adding additional keys in the <b>values.json.</b></li>
                        </ul>
                    <li>Click <b>Edit</b> to define the line item descriptions for each of the Cash Flow structures required.</li>
                </ul>
                <br>The <b>Edit</b> dialog provides the following options:
                <ul>
                    <li><b>Clear all</b> - removes all line descriptions from all sections.</li>
                    <li><b>Restore original</b> - restores the line descriptions to the default ones as defined in the values.json file.</li>
                    <li><b>Set new default</b> - saves the current values entered as the new default to be used for future structures.</li>
                    <li><b>Save</b> - saves the values that have been entered.</li>
                </ul>
                    </li>`,
                csvImportGuidance: `You have selected to import cash flow balances from a CSV file.
                <br><br>Import the CSV file containing line numbers, IDs, line descriptions, current year and prior year balances by clicking the <b>CSV Import</b> button.
                <br><br>Values that are imported will flow to the Statement of cash flow in the Financial Statements document.`,
                importBalanceInfo: 'You have selected to import cash flow balances from a CSV file. The CSV file must match the structure defined in the example file, which can be downloaded from here. '+
                'Import the CSV file containing line numbers, IDs, line descriptions, current year and prior year balances by clicking the CSV Import button. '+
                'Values that are imported will flow to the Statement of cash flow in the Financial Statements document.',
                overviewSectionTitle:'Overview',
                csvVsCopyQuestion: `Select the method to insert the cash flow amounts into this form:`,
                csvVsCopyQuestionGuidance:`The cash flow import tool supports two methods to insert the amounts into this form:
                <ul>
                    <li><b>CSV Import</b>: Import the amounts using the predefined CSV template file provided.</li>
                    <li><b>Copy-Paste</b>: Allows you to directly copy paste the amounts for each of the applicable cash flow sections.</li>
                </ul>`,
                csvVsCopyQuestionYes: `CSV Import`,
                csvVsCopyQuestionNo: `Copy-Paste`,
                importPyQuestion: `Do you want to import prior year balances?`,
                importPyGuidance:`Select <b>Yes</b> to import the Prior Year balances.
                <br><br> If you select <b>No</b>, you will  not be able to import the prior year balances.`,
                csvSelection: "Import cash flow balances from CSV",
                copyPasteGuidance: `You have chosen to copy the cash flow balances from a CSV or Excel file.
                <br><br>Proceed to the next tabs and transfer the amounts from the CSV or Excel file into the pre-generated tables.
                <br><br>Values that are copied will  be automatically transferred to the Statement of cash flow in the Financial Statements document.`,
                roundedFSLabel: `Specify whether the amounts you want to import or copy are already rounded or not:`,
                roundedFSGuidance: `Financial statements can be rounded to thousands, millions, and billions.
                <br><br>Specify whether the amounts imported/copied are already Rounded as per the financial statements rounding settings.
                <br><br>If the amounts are not rounded, the form will automatically apply the same rounding settings as specified in the financial statements rounding settings.
                <br><br>To enable rounding in the financial statements refer to <a href=${wpw.tax.gcs.hardLink.customizeRounding} target=”_blank”>Customize rounding in the financial statements</a>.`, 
                roundedFSLabelY: `Rounded`,
                roundedFSLabelN: `Not rounded`,
                generateDefaultLabel: `Copy cash flow balances`,
                generateDefaultButton: `Generate cash flow sections`,
                rfDefaultLabel: ` Do you want to revert back to the template default descriptions?`,
                rfDefaultLabelY: `Yes`,
                rfDefaultLabelN: `No`,
                summaryHeader: 'Cash flow summary details',
                introLabel: 'Import cash flow balances from CSV',
                csvSelectionBtn: 'CSV Import',
            },
        },
        tables: {
            "en": {
                frameworkHeader: 'Financial reporting framework',
                frameworkHeaderGuidance: 'Applicable financial reporting frameworks are based on the procedure documented in the <b>Settings</b> section.',
                industryHeader: 'Industry / Sectors',
                cfMethodLabel: 'Cash Flow Method',
                industryHeaderGuidance:'Applicable Industries/Sectors are based on the procedure documented in the <b>Settings</b> section.',
                cfCashGroupNumberLabel: 'Cash and Cash equivalents financial groupings',
                cfCashGroupNumberGuidance:'Select the financial groupings which add up to the <b>cash and cash equivalents</b> balance which is used for the cash flow statement.'+
                '<br><br>Balance will be used to cross-check amounts in the summary section.',
                cashFlowActivitiesCol0Header: 'Account number',
                cashFlowActivitiesCol1Header: 'Account description',
                cashFlowActivitiesCol2Header: 'Current year',
                cashFlowActivitiesCol2TotalMsg: 'Net cash flows - operating activities',
                cashFlowActivitiesCol3Header: 'Prior year',
                cashFlowActivitiesCol4Header: 'Current year (Rounded)',
                cashFlowActivitiesCol5Header: 'Prior year (Rounded)',
                cashFlowDirectOperatingActivitiesTitle: "Direct operating activities",
                cashFlowIndirectOperatingActivitiesTitle: "Indirect operating activities",
                cashFlowOperatingActivitiesTitle: "Operating activities",
                cashFlowInvestingActivitiesCol2TotalMsg: 'Net cash flows - investing activities',
                cashFlowInvestingActivitiesTitle: "Investing activities",
                cashFlowFinancingActivitiesTitle: "Financing activities",
                cashFlowFinancingActivitiesCol2TotalMsg: 'Net cash flows - financing activities',
                grandTotalCol2TotalMsg: 'Cash and cash equivalents, ending of the period',
                grandTotalCol2TotalMsgGuidance:'This represents the calculated cash and cash equivalents balance based on the amounts imported/copied in this form.',
                cashTableLabel: 'Engagement cash and cash equivalents balance',
                cashTableGuidance:`Cash and cash equivalents balance is read from the engagement financial statements. It accounts for any Rounding settings the user applies to the financial statements.
                <br><br>To learn more about rounding in the financial statements, refer to <a href=${wpw.tax.gcs.hardLink.customizeRounding} target=”_blank”>Customize rounding in the financial statements</a>.`,
                adjustmentRecProfit: "Adjustments to reconcile profit before tax to net cash flows:",
                workingCapitalChanges: "Working capital changes:",
                activitiesEditBtn: "Add",
                cashPaidTotal: "Total cash paid",
                totalNoncashInvestingFinancingActivities: "Total noncash investing and financing activities",
                totalSupplementalCF: "Total supplemental cash flow information",
            }
        },
        calc: {
            "en": {
                checkToolTip:'Calculated result matches the engagement Cash and cash equivalents balance.',
                errorToolTip:'Calculated result does not match the engagement Cash and cash equivalents balance.',
                warningToolTip:'A difference exists for the ',
                warningToolTip1:' between the total of the amounts imported and the total of the rounded amounts.',
                CashAndCashEquivalentsAccountNumber: 'CashAndCashEquivalentsAtCarryingValue',
                roundedFSLabel: 'Is the amount entered in the cash flow statement rounded according to the financial statement?',
                cyHeader: 'Current year',
                pyHeader: 'Prior year',
                fsRoundedLabel: 'The financial statement has been rounded to one.',
                fsRoundedLabelOption1000: 'The financial statement has been rounded to thousands.',
                fsRoundedHeaderOption1000: ' (in thousands)',
                fsRoundedLabelOption1000000: 'The financial statement has been rounded to millions.',
                fsRoundedHeaderOption100000: ' (in millions)',
                fsRoundedLabelOption1000000000: 'The financial statement has been rounded to billions.',
                fsRoundedHeaderOption1000000000: ' (in billions)',
                errorDialogHeader: 'Error',
                generateTabTableHeader: 'Update',
                generateTabTableMsg: 'Cash flow sections have been generated. Proceed to the next tabs and transfer the amounts from the CSV to the Excel file into the pre-generated tables.',
                cellLimitLabel: 'You have inserted a value that exceeds the allowed limit defined for this form. Each section has a set number of maximum rows that are defined in your product <i>values.json</i> file.',
                cellLimitPluralLabel: 'More than one activity cells size exceed the allowable row size.',
                incompleteImportDialogMsg: 'The file you are trying to import is not following the correct structure. Review the file and import it again.',
                incompleteImportClose: 'Close',
                completionDialogHeader: 'CSV file imported',
                completionDialogMsg: 'CSV file has been imported.<br><br>Refresh the page to see the information imported.',
                loadCSVDialogHeader: 'CSV Import',
                loadCSVDialogMsg: `You have selected to import cash flow balances from a CSV file.<br><br> Proceed with the CSV file import?`,
                genDefDialogHeader: 'Warning',
                genDefDialogMsg: 'If you choose to proceed to generate table, your previous entered values will be ' +
                    '<b>deleted</b> and will be replaced with the default values. <br> <br> Will you like to proceed? ',
                frameworkDiffLabel: 'The framework has been changed since the last cash flow table generation. ',
                industryDiffLabel: 'The industry has been changed since the last cash flow table generation. ',
                cfEndingDiffLabel: 'Please click on generate default table to update to default description.',
                cfEndingDiffCSVLabel: 'Please click on CSV import to update to default description.',
                cfDynamicFlowLabel: 'Net cash flows from/(used in) ',
                cfDynamicFlowInLabel: 'Net cash flows from ',
                cfDynamicFlowOutLabel: 'Net cash flows used in ',
                editBtn: 'Edit',
            }
        }
    }

    //addition for GCS version 23.4.0
    const decimalSepSwitch = {
        ',' : '.',
        '.' : ','
    }
    const separatorWords = {
        ',' : 'comma',
        '.' : 'dot'
    }

    wpw.tax.gcs.formLabels[currentForm]['calc']['en'].loadCSVDialogYes = "Yes";
    wpw.tax.gcs.formLabels[currentForm]['calc']['en'].loadCSVDialogNo = "No";
    wpw.tax.gcs.formLabels[currentForm]['formData']['en'].csvDecimalLabel = "Select the box if your CSV file number format " +
        "(for decimals and digit grouping symbols) is different from the Engagement Settings numbers format.";
    wpw.tax.gcs.formLabels[currentForm]['formData']['en'].csvDecimalGuidance = "By default, Import CSV assumes the file numbers " +
        "format matches the Engagement Settings → Format → Numbers for the decimals and digit grouping symbols." +
        "<br>" + "This Engagement Settings → Format → Numbers is defined as follows: " +
        "<br>" +
        "<br>" +
        `• Decimals symbol = ${wpw.tax.gcs.format.decimalSeperator} (${separatorWords[wpw.tax.gcs.format.decimalSeperator]})` +
        "<br>" +
        `• Digit symbol= ${decimalSepSwitch[wpw.tax.gcs.format.decimalSeperator]} (${separatorWords[decimalSepSwitch[wpw.tax.gcs.format.decimalSeperator]]})` +
        "<br>" +
        "<br>" +
        "Select the box if your CSV file uses different number format settings.";

    wpw.tax.gcs.setProdGCSLabel(currentForm);
})();