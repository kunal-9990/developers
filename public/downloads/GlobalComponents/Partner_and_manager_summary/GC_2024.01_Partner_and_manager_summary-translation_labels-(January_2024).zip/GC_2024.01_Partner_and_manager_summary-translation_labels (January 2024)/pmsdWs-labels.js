(function () {
    'use strict';

    if (!wpw.tax.gcs) wpw.tax.gcs = {};
    if (!wpw.tax.gcs.formLabels) wpw.tax.gcs.formLabels = {};
    let currentForm = 'pmsdWs'

    wpw.tax.gcs.hardLink = wpw.tax.gcs.hardLink || {};

    // wpw.tax.gcs.hardLink[""] = ""
    
    wpw.tax.gcs.formLabels[currentForm] = {
        formdata: {
            "en": {
                formDataTitlePmsd: 'PA - Partner and manager summary worksheet',
                sectionHeader: 'Edit severity color',
                procedureName: 'Procedure name',
                okButton: 'OK',
            }
        },
        tables: {
            "en": {
                procedureResponse: 'Procedure Response',
                severityStyle: 'Severity color',
                black: 'Black',
                green:'Green',
                orange: 'Orange',
                red: 'Red'
            }
        },
        calc: {
            "en": {

            }
        }
    }

    wpw.tax.gcs.setProdGCSLabel(currentForm);
})();