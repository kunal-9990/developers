(function () {
  'use strict';

  if (!wpw.tax.gcs) wpw.tax.gcs = {};
  if (!wpw.tax.gcs.formLabels) wpw.tax.gcs.formLabels = {};
  let currentForm = 'pmsd';

  wpw.tax.gcs.hardLink = wpw.tax.gcs.hardLink || {};

  wpw.tax.gcs.hardLink['engagementPhases'] =
    'https://developers.caseware.com/se-authoring/31/Define-the-engagement-phases.htm';
  wpw.tax.gcs.hardLink['pmSummary'] =
    'https://developers.caseware.com/se-authoring/31/Partner-and-manager-summary.htm';
  wpw.tax.gcs.hardLink['analysisModule'] =
    'https://developers.caseware.com/sdk/cloud/Reference/SE/tutorial-analysis-module.html';
  wpw.tax.gcs.hardLink['procedureId'] =
    'https://developers.caseware.com/se-authoring/31/How-to-identify-the-procedure-ID.htm';
  wpw.tax.gcs.hardLink['riskAssessment'] =
    'https://developers.caseware.com/se-authoring/31/Enable-the-new-risk-module.htm';

  wpw.tax.gcs.formLabels[currentForm] = {
    formdata: {
      en: {
        financialInfoHeader: 'Financial information',
        insertGraphId: 'Analysis module ID:',
        financialAdditionalInfoLinkTipGuidance:
          'If applicable to your solution, insert the document URL where the Overview analytical review graph is located. This URL will be used as the reference link that is displayed at the engagement level. URL example: #/analysis/1tj5YMx_SvufwYOGuJ7SZw',
        financialAdditionalInfoDocNameTipGuidance:
          'If applicable to your solution, insert the name for the Overview analytical review document specific to your solution that you want to show in the reference link. <b>Example</b>: B100 Analytical review',
        graphIdTipGuidance:
          'Insert here the Analysis module ID that you want to include in this widget. <b>ID example</b>: 1tj5YMx_SvufwYOGuJ7SZw (last part of the analysis module document URL)',
        fieldWorkHeader: 'Fieldwork',
        planningHeader: 'Planning',
        insertLinkId: 'Insert document URL:',
        insertGraphLinkId: 'Overview analytical review document URL:',
        insertDocNameGraph: 'Overview analytical review document name:',
        engageTmInsertLinkIdTipGuidance: `Insert the document URL where the Engagement team is documented. This URL will be used for the reference link that is displayed at the engagement level.<br><br>
                <b>URL example</b>: #/checklist/Ca0wmJVyRwqVSrmUgQ_Jsg`,
        insertDocName: 'Document name:',
        engageTminsertDocNameTipGuidance: `Insert the name of the document where Engagement team information is stored.<br><br>
                <b>Example</b>: 4-300 Overall Audit Strategy`,
        noDocs: 'No documents with specific rolesets found in this phase',
        placeholder_Text: 'PLACEHOLDER TEXT',
        procedureNotCompleted: 'Procedure not completed',
        fsLevelprocedureRiskId:
          'Assessed risks at the financial statement level procedure ID',
        fsLevelprocedureRiskIdTipGuidance: `If your app supports documenting the <b>assessed risks at the financial level</b>, insert the <b>procedure ID</b> where this information is documented in the engagement.
                <br><br>
                If your app does not support this, leave this field blank.
                <br><br>
                For instructions on how to identify the procedure ID, click <a href=${wpw.tax.gcs.hardLink.procedureId} target=”_blank”>here</a>.`,
        riskInsertLinkIdTipGuidance: `Insert the document URL where the <b>assessed risks at the financial level</b> is documented. This URL will be used for the reference link that is presented at the engagement level.
                <br><br>
                <b>URL example</b>: #/checklist/YIp_7-zVQiuD3K7my8X13A`,
        riskInsertDocNameTipGuidance: `Insert the name of the document where Engagement team information is stored.
                <br><br>
                <b>Example</b>: B400 Assessment of RMM`,
        completionInsertLinkIdTipGuidance: `Insert the document URL of the <b>Summary of Misstatements</b> document. This URL will be used for the reference link that is presented at the engagement level.
                <br><br>
                <b>URL example</b>: #/checklist/YIp_7-zVQiuD3K7my8X13A`,
        completionInsertDocNameTipGuidance: `Insert the name of <b>Summary of Misstatements</b> document.
                <br><br>
                <b>Example</b>:7-100 Summary of Misstatements`,
        referTo: 'Refer to',
        forAdditionalInfo: 'for additional information.',
        noRisks: 'No risks created',
        noControls: 'No controls created',
        noDocsInPhase: 'No documents found in this phase',
        referToThe: 'Refer to the',
        fieldWork: 'FIELDWORK',
        noCustomConclusions: 'No custom conclusions found in this phase',
        noIssues: 'No issues created',
        noAdjustmentsCreated: 'No adjustments created',
        noDocsFound: 'No documents found',
        overallSetting: 'Settings',
        overallEngagementSetting: 'Overall engagement information',
        overallEngagementSubHeading: 'Overall engagement information',
        engagementTeam: 'Engagement team',
        riskAssessmentResponseHeader: 'Risk assessment and response',
        risksHeader: 'Risks',
        controlsHeader: 'Controls',
        planningAuditResponses: 'Planned audit responses',
        docsRequiringRoleSets: 'Documents requiring specific rolesets',
        docsWithNonOpAns: 'Documents with non optimal answers',
        noDocsNonOpAns:
          'No documents with non optimal answers found in this phase',
        docsCustomConclusion: 'Documents with custom conclusion',
        completionHeader: 'Completion',
        issuesHeader: 'Issues',
        adjustmentsHeader: 'Adjustments',
        docWithOverriddenVis: 'Documents with overridden visibility',
        noDocsOverriddenVis: 'No documents with overridden visibility found',
        docModAfterSignOff: 'Documents modified after sign off',
        asaRequirments: 'ASA Requirements (Australia)',
        sebTable: 'Engagement team information location: ',
        sebTableSec: 'SE Checklist',
        sebTableSeb: 'SE Builder table',
        useSEBTableTipGuidance:
          'Answer <b>SE Checklist</b> if the Engagement team information is documented within a single procedure.<br> Answer <b>SE Builder table</b>  if the Engagement team information is documented in a different SE Builder document/table.',
        overallSettingsGuidance: `The table below allows Primary Authors to configure the content of the <b>Partner and manager summary</b> (PMS) based on the solution it is integrated into.
                <ul>
                    <li>The <b>Form tabs</b> column includes the list of tabs names that form the structure of the PMS form. Use this column to modify the tabs names based on your solution specific requirements.</li>
                    <li>In the <b>Widget</b> column there is a list of available widgets for each of the tabs. Choose which ones to include based on your solution.</li>
                    <li><b>Engagement phases</b> allows Primary Authors to align SE Engagement document phases with PMS tabs. You can select one or multiple phases that correspond to any particular tab. This information is used throughout the rest of the PMS functionality to properly filter the correct information for each of the applicable widgets. To find out more about Engagement phases, see <a href=${wpw.tax.gcs.hardLink.engagementPhases} target=”_blank”>Define the engagement phases</a>.</li>
                    <li><b>Folders</b>: allows Primary Authors to further filter which folders align with a particular tab and be used throughout the rest of the PMS functionality to properly filter the correct information for each of the applicable widgets. By default, all folders associated with an <b>Engagement phase</b> will be selected, but if the <b>Engagement phase</b> selection is changed, then the <b>Folders</b> selection should be revised.</li>
                </ul>
                <br>Before configuring the PMS content based on your solution specific requirements, we recommend reading the <a href=${wpw.tax.gcs.hardLink.pmSummary} target=”_blank”>Partner and manager summary</a> topic on SE Authoring guide.<br><br>`,
        financialInfoGuidance: `The Financial information widget includes Analysis graph information. Primary authors can specify which <a href=${wpw.tax.gcs.hardLink.analysisModule} target=”_blank”>analysis module</a> should be included, based on the list available in their solution.`,
        overallEngagementInfoGuidance: `<b>Overall engagement information</b> widget lists out the key responses from the engagement based on the information defined in the table below:
                <ul>
                    <li><b>Procedure ID</b> -  Insert the <b>procedure ID</b> of the information you want to be presented. For instructions on how to identify the procedure ID, click <a href=${wpw.tax.gcs.hardLink.procedureId} target=”_blank”>here</a></li>
                    <li><b>Procedure name</b> - Provide the description that you want to be presented in the table. If no description is provided, the default text of the procedure will be used</li>
                    <li><b>Yes / No response</b> - The checkbox allows selecting <b>Yes</b> or <b>No</b> as a response based on the procedure type. It will reflect Yes for procedures responded to as Narrative or Procedure and No for those responded to as <b>N/A</b>. This check box is specific to certain types of procedures that entail Narrative, Procedure or N/A as inline responses. For other procedure types, the checkbox should remain unchecked. </li>
                    <li><b>Edit severity color</b> - Select the pencil icon to define the color of the responses based on their severity. For example: <b>High</b> - <font color="red">Red</font> / <b>Medium</b> - <font color="orange">Orange</font> / <b>Low</b> - <font color="green">Green</font></li>
                </ul>`,
        engagementTeamGuidance: `The <b>Engagement team</b> widget displays documented team information specific to your engagement.<br> 
                <b>Note</b>: This widget supports the following scenarios:<br><br>                
                <b>Case 1</b>: Where the Engagement team information is documented within a single procedure in a SE checklist, allowing for multiple rows,it will display information about <b>Position</b> and <b>Name</b>. Answer <b>SE Checklist</b> if this scenario applies and fill in the following information:
                <ul>
                    <li><b>Procedure ID</b> -  Insert the <b>procedure ID</b> where the engagement team information is documented. For instructions on how to identify the procedure ID, click <a href=${wpw.tax.gcs.hardLink.procedureId} target=”_blank”>here</a></li>
                    <li><b>Read procedure information</b> - Click on the button to retrieve information on how responses are defined for the procedure</li>
                    <li><b>Position / Name</b> - Specify which of the procedure responses represent the <b>Position</b> or the <b>Name</b></li>
                </ul>
                <b>Case 2</b>: Where the Engagement team information is documented in a different SE Builder document/table respond with <b>SE Builder table</b> if this scenario applies, and follow the instructions listed under the Engagement team widget information <a href=${wpw.tax.gcs.hardLink.pmSummary} target=”_blank”>here</a>`,
        riskAssessmentResponseGuidance: `The <b>Risks</b> widget displays information about <b>Risks</b> documented in the engagement file:
                <ul>
                    <li><b>Assessed risks</b> at the financial level: If your app supports documenting the assessed risks at the financial level:</li>
                        <ul>
                            <li>Insert the <b>procedure ID</b> where the engagement team information is documented.  For instructions on how to identify the procedure ID, click <a href=${wpw.tax.gcs.hardLink.procedureId} target=”_blank”>here</a></li>
                            <li>Document the <b>URL</b> and the <b>name</b> of the checklist containing this information to create the reference on the PMS document tab</li>
                        </ul>
                    <li>Automatically displays the <b>total number</b> of risks documented in the engagement file</li>
                    <li>Automatically displays the number of <b>significant risks</b> identified in the engagement file</li>
                    <li>Automatically displays the number of <b>fraud risks</b> identified in the engagement file</li>
                </ul>
                <br>
                The <b>Risk report</b> reference included on the widget automatically directs the end user to the <a href=${wpw.tax.gcs.hardLink.riskAssessment} target=”_blank”>Risks assessment</a> tab in the engagement file.`,
        completionGuidance: `The <b>Adjustments</b> widget displays information about <b>Adjustments</b> posted in the engagement file:
                <ul>
                    <li>The <b>total</b> number of adjustments recorded in the engagement file for the current year, excluding any Tax Adjustments posted</li>
                    <li>The total number of <b>proposed</b> (Unrecorded - Factual / Projected / Judgmental) adjustments recorded in the engagement file for the current year</li>
                    <li>The total number of <b>actual</b> (Normal and Reclassifying) adjustments recorded in the engagement file for the current year</li>
                    <li>The total number of <b>eliminating</b> adjustments recorded in the engagement file for the current year,  if applicable,  and the engagement is set as a Consolidation</li>
                </ul>
                `,
      },
    },
    tables: {
      en: {
        auditStep: 'Form tabs',
        procedureId: 'Procedure ID',
        nameOfProcedure: 'Description of key information',
        switchOnResponse: 'Yes / No response',
        editHeader: 'Edit severity color',
        grabColId: 'Read procedure information',
        positionResponseId: 'Position',
        nameResponseId: 'Name',
        positionHeader: 'Position',
        nameHeader: 'Name',
        statusHeader: 'Status',
        lastSignoff: 'Last Sign-off',
        engagementPhasesHeader: 'Engagement phases',
        signoffHeader: 'Sign-off',
        asaSeries: 'ASA Series',
        partnerRole: 'Partner',
        managerRole: 'Manager',
        seniorRole: 'Senior',
        assistantRole: 'Assistant',
        assistant1Role: 'Assistant 1',
        expertRole: 'Expert',
        eqcrRole: 'EQCR',
        hideAdditionDetails: 'Hide additional details',
        showAdditionDetails: 'Show additional details',
        documentPagePhasesTitle: 'Documents Page Phases',
        planningPhase: 'Planning',
        financialInfoWidget: 'Financial information',
        OverallEngInfoWidget: 'Overall engagement information',
        engagementTeamWidget: 'Engagement team',
        riskAssessmentResponsePhase: 'Risk assessment and response',
        risksWidget: 'Risks',
        controlsWidget: 'Controls',
        plannedAuditResponsesWidget: 'Planned audit responses',
        docsRequiringRoleSetsWidget: 'Documents requiring specific rolesets',
        fieldworkPhase: 'Fieldwork',
        nonOptimalWidget: 'Documents with non optimal answers',
        checklistsCustomConclusionWidget: 'Checklists with custom conclusions',
        completionPhase: 'Completion',
        issuesWidget: 'Issues',
        adjustmentsWidget: 'Adjustments',
        docsWithOverriddenVisWidget: 'Documents with overridden visibility',
        docsModAfterSignoffWidget: 'Documents modified after sign off',
        foldersHeader: 'Folders',
        nonOptimalTableCol1Header: 'Document',
        nonOptimalTableCol2Header: 'Link',
        nonOptimalTableCol3Header: 'Non optimal answers',
        forcedVisDocsTableCol1Header: 'Document',
        forcedVisDocsTableCol2Header: 'Link',
        forcedVisDocsTableCol3Header: 'Visibility',
      },
    },
    calc: {
      en: {
        narrativeSwitchResponse: 'Narrative',
        proceduresSwitchResponse: 'Procedures',
        yesSwitchResponse: 'Yes',
        noSwitchResponse: 'No',
        fetchProcedures: 'Yes',
        missingSummaryText: 'Missing',
        completeSummaryText: 'Complete',
        inprogressSummaryText: 'In progress',
        informationConsolidated: 'Consolidated',
        notApplicable: 'N/A',
        fsLevelTitle: 'Financial statement level',
        totalTitle: 'Total',
        significantTitle: 'Significant',
        fraudTitle: 'Fraud',
        keyTitle: 'Key',
        proposedTitle: 'Proposed',
        actualTitle: 'Actual',
        eliminatingTitle: 'Eliminating',
        referTo: 'Refer to',
        forAdditionalInfo: 'for additional information.',
        signoffHeaderName: 'Sign-offs',
        and: 'and',
        andThe: 'and the',
        settingsAppend: 'Settings',
        planningPhase: 'Planning',
        financialInfoWidget: 'Financial information',
        OverallEngInfoWidget: 'Overall engagement information',
        engagementTeamWidget: 'Engagement team',
        riskAssessmentResponsePhase: 'Risk assessment and response',
        risksWidget: 'Risks',
        controlsWidget: 'Controls',
        plannedAuditResponsesWidget: 'Planned audit responses',
        docsRequiringRoleSetsWidget: 'Documents requiring specific rolesets',
        fieldworkPhase: 'Fieldwork',
        nonOptimalWidget: 'Documents with non optimal answers',
        checklistsCustomConclusionWidget: 'Checklists with custom conclusions',
        completionPhase: 'Completion',
        issuesWidget: 'Issues',
        adjustmentsWidget: 'Adjustments',
        docsWithOverriddenVisWidget: 'Documents with overridden visibility',
        docsModAfterSignoffWidget: 'Documents modified after sign off',
      },
    },
  };

  wpw.tax.gcs.setProdGCSLabel(currentForm);
})();
