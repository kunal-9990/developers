function OnPreFilePublish() {
    var result = MessageBox(
        "CaseWare SDK",
        "OnPreFilePublish Event" +
            "\nPublish File?",
        MESSAGE_YESNO
    );
    return result === MESSAGE_RESULT_YES;
}