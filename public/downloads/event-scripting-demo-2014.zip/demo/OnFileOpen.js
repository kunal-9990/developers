/***************************************************************************************
//
// Event:   OnFileOpen
// Description: Display a message on file open.
//
***************************************************************************************/

function OnFileOpen()
{
    MessageBox(
        "CaseWare SDK",
        "OnFileOpen Event",
        MESSAGE_OK
    );
}

