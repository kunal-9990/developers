/**
 * OnPreProgramLaunch.js
 */

function OnPreProgramLaunch(args) {

	//Set the value of a variable on the Storage object.
	Storage.foo = "bar";

	if(args[1] === '/dde') {
		// It is NOT safe to display modal dialogs if Working Papers is
		//   launched with the parameter /dde as the first argument.
	} else {
		MessageBox("CaseWare SDK", "OnPreProgramLaunch Event\nargs: [" + args.join(', ') + "]", 0);
	}
}