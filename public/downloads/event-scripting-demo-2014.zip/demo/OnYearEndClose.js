function OnYearEndClose(location, lockdown) {
    MessageBox(
        "CaseWare SDK",
        "OnYearEndClose Event" +
            "\n\tlocation: " + location +
            "\n\tlockdown: " + lockdown,
        MESSAGE_OK
    );
}