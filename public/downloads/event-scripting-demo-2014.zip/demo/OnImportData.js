//////////////////////////////////////////////////////////////////////////////
// Event:   OnImportData
// Description: On import of data from the file of this directory, notify
//      the user that an import has completed
//
//////////////////////////////////////////////////////////////////////////////

function OnImportData(importType, importFile)
{
    MessageBox(
        "CaseWare SDK",
        "OnImportData Event" +
            "\n\timportType: " + importType +
            "\n\timportFile: " + importFile,
        MESSAGE_OK
    );
}