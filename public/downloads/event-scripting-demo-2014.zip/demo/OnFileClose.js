function OnFileClose()
{
    MessageBox(
        "CaseWare SDK",
        "OnFileClose Event",
        MESSAGE_OK
    );
}