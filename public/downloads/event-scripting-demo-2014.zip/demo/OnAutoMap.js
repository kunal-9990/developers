function OnAutoMap(source) {
    MessageBox(
        "CaseWare SDK",
        "OnAutoMap Event" +
        "\n\tsource: " + source,
        MESSAGE_OK
    );
}