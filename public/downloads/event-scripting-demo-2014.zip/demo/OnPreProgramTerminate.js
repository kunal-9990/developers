function OnPreProgramTerminate() {
    var result = MessageBox(
        "CaseWare SDK",
        "OnPreProgramTerminate Event" +
            "\nQuit Working Papers?",
        MESSAGE_YESNO
    );
    return result === MESSAGE_RESULT_YES;
}