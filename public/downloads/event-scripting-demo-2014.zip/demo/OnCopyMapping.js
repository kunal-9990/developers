/***************************************************************************************
//
// Event:   OnCopyMapping
// Description: When mapping is copied, loop through all the accounts and remap where
//      necessary
// Parameters:  templateFile - the full path of the source template
//
***************************************************************************************/
function OnCopyMapping(templateFile)
{
    MessageBox(
        "CaseWare SDK",
        "OnCopyMapping Event" +
            "\n\ttemplateFile: " + templateFile,
        MESSAGE_OK
    );
}