function OnProgramLaunch() {
    MessageBox(
        "CaseWare SDK",
        "OnProgramLaunch Event",
        MESSAGE_OK
    );
}