//////////////////////////////////////////////////////////////////////////////
// Event: 	OnFileNew
// Description: On creation of a new file based on the one in this directory,
//		set the client name to "Client001"
//
//////////////////////////////////////////////////////////////////////////////

function OnFileNew()
{
	MessageBox(
        "CaseWare SDK",
        "OnFileNew Event",
        MESSAGE_OK
    );
}

