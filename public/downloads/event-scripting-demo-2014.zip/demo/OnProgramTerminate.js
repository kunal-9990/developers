function OnProgramTerminate() {
    MessageBox(
        "CaseWare SDK",
        //Display the value saved in Storage.foo on program launch.
        "OnProgramTerminate Event\nStorage.foo: " + Storage.foo,
        MESSAGE_OK
    );
}