function OnPreAutoMap(source) {
    var result = MessageBox(
        "CaseWare SDK",
        "OnPreAutomap Event" +
            "\n\tsource:" + source +
            "\nAutomap File?",
        MESSAGE_YESNO
    );
    return result === MESSAGE_RESULT_YES;
}